from web3 import Web3
import json

# Connect to Ganache
BLOCKCHAIN_PROVIDER = "http://127.0.0.1:7545"
w3 = Web3(Web3.HTTPProvider(BLOCKCHAIN_PROVIDER))

# Use the deployed contract address from Remix
CONTRACT_ADDRESS = "0x11B8946AF29913Cd2dA64De8E6f3EdfeF2f294d2"

# Corrected ABI (list of dictionaries)
CONTRACT_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {
                "indexed": False,
                "internalType": "string",
                "name": "userId",
                "type": "string"
            },
            {
                "indexed": False,
                "internalType": "string",
                "name": "imageHash",
                "type": "string"
            }
        ],
        "name": "IdentityStored",
        "type": "event"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "userId",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "imageHash",
                "type": "string"
            }
        ],
        "name": "storeIdentity",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "userId",
                "type": "string"
            }
        ],
        "name": "getIdentity",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
]

# Connect contract
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=CONTRACT_ABI)
