from web3 import Web3
import config

w3 = Web3(Web3.HTTPProvider(config.BLOCKCHAIN_PROVIDER))
contract = w3.eth.contract(address=config.CONTRACT_ADDRESS, abi=config.CONTRACT_ABI)

print("Contract Deployed:", contract.address)
