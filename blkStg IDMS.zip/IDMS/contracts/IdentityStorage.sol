// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract IdentityStorage {
    // Mapping to store user identity hashes
    mapping(string => string) private identities;

    // Event for logging identity storage
    event IdentityStored(string userId, string imageHash);

    // Function to store user identity data
    function storeIdentity(string memory userId, string memory imageHash) public {
        identities[userId] = imageHash;
        emit IdentityStored(userId, imageHash);
    }

    // Function to retrieve user identity hash
    function getIdentity(string memory userId) public view returns (string memory) {
        return identities[userId];
    }
}
