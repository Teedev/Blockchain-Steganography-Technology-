import json
from flask import Flask, request, render_template
from web3 import Web3
from steganography import embed_data
import config

app = Flask(__name__)

# ✅ Connect to Ethereum
w3 = Web3(Web3.HTTPProvider(config.BLOCKCHAIN_PROVIDER))

# ✅ Load Smart Contract ABI
try:
    with open("contract_abi.json") as abi_file:
        contract_abi = json.load(abi_file)

    # 🚨 Ensure ABI is a list of dictionaries
    if not isinstance(contract_abi, list):
        raise ValueError("ERROR: ABI must be a list of dictionaries. Check contract_abi.json!")

except (FileNotFoundError, json.JSONDecodeError) as e:
    print(f"ERROR: Failed to load ABI - {e}")
    contract_abi = None

# ✅ Load Contract Address
contract_address = config.CONTRACT_ADDRESS

if contract_abi:
    contract = w3.eth.contract(address=contract_address, abi=contract_abi)
else:
    contract = None

# ✅ Route to Upload Identity Data
@app.route('/', methods=['GET', 'POST'])
def upload_identity():
    if request.method == 'POST':
        user_id = request.form['user_id']
        image = request.files['image']
        identity_data = f"UserID:{user_id}|Role:Admin"

        # ✅ Save Image
        image_path = f"static/uploads/{image.filename}"
        image.save(image_path)

        # ✅ Embed Data into Image
        stego_path = f"static/stego/{image.filename}"
        embed_data(image_path, identity_data, stego_path)

        # ✅ Store Hash on Blockchain
        if contract:
            with open(stego_path, 'rb') as f:
                image_hash = Web3.keccak(f.read()).hex()
                txn = contract.functions.storeIdentity(user_id, image_hash).transact({'from': w3.eth.accounts[0]})
                w3.eth.wait_for_transaction_receipt(txn)

            return "Identity stored successfully!"
        else:
            return "ERROR: Smart contract not loaded."

    return render_template('upload.html')

if __name__ == "__main__":
    app.run(debug=True)
