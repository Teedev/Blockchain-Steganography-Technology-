from stegano import lsb
import cv2

def embed_data(image_path, data, output_path):
    # Load and preprocess image
    image = cv2.imread(image_path)
    resized_image = cv2.resize(image, (512, 512))
    cv2.imwrite("resized_cover.png", resized_image)

    # Embed data using LSB
    secret = lsb.hide("resized_cover.png", data)
    secret.save(output_path)
    print(f"Data embedded into {output_path}")

# Example usage with a Tom and Jerry image
embed_data("tom_001.png", "UserID:123|Name:John Doe|Role:Admin", "stego_tom.png")
