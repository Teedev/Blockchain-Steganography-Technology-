from flask import Flask, request, render_template
from web3 import Web3
from steganography import embed_data
import os
import config

app = Flask(__name__)

# ✅ Connect to Ethereum
w3 = Web3(Web3.HTTPProvider(config.BLOCKCHAIN_PROVIDER))

# ✅ Load Contract
contract = w3.eth.contract(address=config.CONTRACT_ADDRESS, abi=config.CONTRACT_ABI)

# ✅ Ensure upload directories exist
UPLOAD_FOLDER = "static/uploads"
STEGO_FOLDER = "static/stego"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(STEGO_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def upload_identity():
    if request.method == 'POST':
        try:
            # ✅ Get form data
            user_id = request.form['user_id']
            image = request.files['image']
            if not user_id or not image:
                return "ERROR: Missing User ID or Image file."

            print(f"Received User ID: {user_id}")

            # ✅ Save Image
            image_path = os.path.join(UPLOAD_FOLDER, image.filename)
            image.save(image_path)

            # ✅ Embed Data into Image
            identity_data = f"UserID:{user_id}|Role:Admin"
            stego_path = os.path.join(STEGO_FOLDER, image.filename)
            embed_data(image_path, identity_data, stego_path)

            # ✅ Store Hash on Blockchain
            with open(stego_path, 'rb') as f:
                image_hash = Web3.keccak(f.read()).hex()
                print(f"Generated Image Hash: {image_hash}")

                txn = contract.functions.storeIdentity(user_id, image_hash).transact({
                    'from': w3.eth.accounts[0]
                })
                w3.eth.wait_for_transaction_receipt(txn)

            return "Identity stored successfully!"
        except Exception as e:
            print(f"ERROR: {e}")
            return f"ERROR: {str(e)}"

    return render_template('upload.html')

if __name__ == "__main__":
    app.run(debug=True)
